This content contains copyright so use it wisely

Source:
https://validthemes.net/site-template/ventix/

This is a free template, we don't tell and fix the directory of the files here, so use your knowledge to decompile this

